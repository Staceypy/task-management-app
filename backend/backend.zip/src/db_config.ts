module.exports = {
  port: 3000, // express server port

  db: {
    host: "localhost",
    port: 3306,
    user: "root",
    password: "123456",
    database: "express_mysql_db",
  },
};
